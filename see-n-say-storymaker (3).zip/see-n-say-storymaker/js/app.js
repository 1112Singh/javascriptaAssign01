
var textToSpeak = ' ';
var speakButton = document.getElementById('textToSpeak');

var Nouns = document.getElementById('Nouns')
var Places = document.getElementById('Places')
var Animals = document.getElementById('Animals')
var Adjectives = document.getElementById('Adjectives')
var Verbs = document.getElementById('Verbs')
var Reset = document.getElementById('Reset')

var nounArr = ['The Turkey' , 'Mom','Dad','Dog','The Elephant','The Cat' , 'The Teacher'];
var adjectiveArr = ['a funny' , 'a scary ','a goofy','a slimy','a barking','a fat'];
var verbArr = ['sat on ' , 'ate','danced with','saw','doesnt like','kissed'];
var animalArr = ['goat' , 'monkey','fish','cow','frog','bug','worm'];
var placesArr = ['on the moon','on the chair','in my soup','in the grass','in my spaghetti','in my shoes'];


/* Functions
-------------------------------------------------- */
function speakNow(string) {
	// Create a new speech object, attaching the string of text to speak
	var utterThis = new SpeechSynthesisUtterance(string);
	// Actually speak the text
	synth.speak(utterThis);
}

/* Event Listeners
-------------------------------------------------- */
// Onclick handler for the button that speaks the text contained in the above var textToSpeak

Nouns.onclick = function() {
  // console.log('nouns btn slicked')
  var int = Math.floor(Math.random() * (nounArr.length -1));
  console.log(int)
  var randomString = nounArr[int];
  textToSpeak = textToSpeak.concat(' '+randomString);
}

Places.onclick = function() {
  console.log('places btn slicked')
  var int = Math.floor(Math.random() * (placesArr.length -1));
  console.log(int)
  var randomString = placesArr[int];
  textToSpeak = textToSpeak.concat(' '+randomString);
}
Animals.onclick = function() {
  console.log('anml btn slicked')
  var int = Math.floor(Math.random() * (animalArr.length -1));
  console.log(int)
  var randomString = animalArr[int];
  textToSpeak = textToSpeak.concat(' '+randomString);
}
Adjectives.onclick = function() {
  console.log('adj btn slicked')
  var int = Math.floor(Math.random() * (adjectiveArr.length -1));
  console.log(int)
  var randomString = adjectiveArr[int];
  textToSpeak = textToSpeak.concat(' '+randomString);
}
Verbs.onclick = function() {
  console.log('vrb btn slicked')
  var int = Math.floor(Math.random() * (verbArr.length -1));
  console.log(int)
  var randomString = verbArr[int];
  textToSpeak = textToSpeak.concat(' '+randomString);
}
speakButton.onclick = function() {
  console.log(textToSpeak)
	speakNow(textToSpeak);
}
